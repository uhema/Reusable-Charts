import { HomepageComponent } from "../homepage/homepage.component";
import { FormComponent } from "../form/form.component";
import { UserdataComponent } from "../userdata/userdata.component";
import { ValidatorComponent } from "../validator/validator.component";
import { LoginpageComponent } from "../loginpage/loginpage.component";
import { UserlistpageComponent } from "../userlistpage/userlistpage.component";


export const MainRoute = [
    {
        path: 'home', 
        component: HomepageComponent
    },
    {
        path: 'product', component: UserlistpageComponent,
    },
    { path: 'product/:id', component: UserdataComponent }


   
]
    
    // {
    //     path: 'form', component: FormComponent
    // },

    // {
    //     path: 'validator', component: ValidatorComponent
    // },
    // {
    //     path: 'login', component: LoginpageComponent
    // }
    
