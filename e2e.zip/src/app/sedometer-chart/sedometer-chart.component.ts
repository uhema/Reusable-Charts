import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sedometer-chart',
  templateUrl: './sedometer-chart.component.html',
  styleUrls: ['./sedometer-chart.component.css']
})
export class SedometerChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
